LMS BLUEPRINT - FICTIONAL CONFIGURATION ONLY
Legacy fictional cleaning blueprint
Exported using the merged PR 16 implementation.

Business: Fictional Basic Cleaning Business
Business type: cleaning
Time zone: America/Los_Angeles
BuildPlan 1 / Engine API 1 / Template 1 / Configuration schema 1

INCLUDED FEATURES AND REQUIRED DEPENDENCIES
customers@1.0.0: Customers
Requires: none
tasks@1.0.0: Tasks
Requires: none
cleaning@1.0.0: Cleaning jobs
Requires: customers, tasks

NAVIGATION
customers: Customers
jobs: Cleaning jobs
tasks: Tasks

SETUP AND SAFE REUSE
1. Run the MIT-licensed LMS using https://github.com/larrinamsalva/LMS and its README setup instructions.
2. Open BuildPlan Studio, choose Import Blueprint Package, then inspect Review Blueprint.
3. Compare features, dependencies, workspace impact and any Gallery revision hint. No update is automatic.
4. Choose Use as unsaved Studio choices, then prepare the actual Engine-powered fictional preview.
5. Save a new draft explicitly. Publishing separately requires the existing impact review and confirmation.

LIMITS AND TRUST
This package contains configuration only. It does not include records, accounts, credentials, databases or executable application code.
Names, descriptions and labels are user-supplied text. Never enter private data or secrets in them.
Checksums detect corruption, not a trusted author. Gallery references are unverified hints, not signatures or upgrade approval.
No hosting, deployment, production authentication, recovery activation, live payments or messaging is enabled.
Populated field-schema changes require separate migration review; this package cannot perform a migration.
Preview and demo drafts are temporary. Keep this downloaded package to retain your choices.
MIT licensing and ForgeOS attribution remain in the LMS repository.
